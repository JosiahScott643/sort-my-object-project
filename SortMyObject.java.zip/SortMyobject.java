import java.io.File; // Import the File class
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Collections;

class SortMyObject {
    public static void main(String[] args) {
        Scanner keyboard = new Scanner(System.in);

        // create song
        Song PlayList = new Song();

        System.out.println("how many songs would you like to add?");
        String SongAmount = keyboard.nextLine();

        int i = Integer.parseInt(SongAmount);
        ArrayList<Song> mySongs = new ArrayList<Song>();

        for (int x = 0; x < i; x++) {
            Song CurrentSong = new Song();

            // ask user for song title data
            System.out.print("What is your song title?");
            String title = keyboard.nextLine();
            PlayList.setTitle(title);

            CurrentSong.setTitle(title);

            // ask user for song artist data
            System.out.print("Who is your artist? ");
            String artist = keyboard.nextLine();
            CurrentSong.setArtist(artist);

            // ask user for song genre data
            System.out.print("What is the genre of the song? ");
            String genre = keyboard.nextLine();
            CurrentSong.setGenre(genre);
            mySongs.add(CurrentSong);

        }
        for (int y = 0; y < mySongs.size(); y++) {
            System.out.println(mySongs.get(y).getTitle());
        }
        try {
            FileWriter myWriter = new FileWriter("PlayList.txt");
            for (int x = 0; x < i; x++) {
                myWriter.write(mySongs.get(x).getTitle() + " " + mySongs.get(x).getArtist() + " "
                        + mySongs.get(x).getGenre() + "\n");
            }
            myWriter.close();

        } catch (IOException e) {
            System.out.print("file not found");

        }

        String SortBy;
        String title2 = "Title";
        String artist2 = "Artist";

        // comparator for song title
        Comparator<Song> compareBytitle = new Comparator<Song>() {
            @Override
            public int compare(Song s1, Song s2) {
                return s1.getTitle().compareTo(s2.getTitle());
            }
        };

        // comparator for song artist
        Comparator<Song> compareByartist = new Comparator<Song>() {
            @Override
            public int compare(Song s1, Song s2) {
                return s1.getArtist().compareTo(s2.getArtist());
            }

        };

        while (true) {
            System.out.println(mySongs);
            System.out.println("how would you like to sort your playlist");
            System.out.println("options include by Title or  Artist");
            SortBy = keyboard.nextLine();

            if (SortBy.equals(title2)) {
                Collections.sort(mySongs, compareBytitle);
            }
            if (SortBy.equals(artist2)) {
                Collections.sort(mySongs, compareByartist);
            }

            System.out.println(mySongs);
        }

    }
}
