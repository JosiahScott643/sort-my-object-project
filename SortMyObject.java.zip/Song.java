//import java.util.*;

// class TitleComparator implements Comparator<Song> {

//     // override the compare() method
//     public int compare(Song s1, Song s2) {
//         return s1.title.compareTo(s2.title);
//     }
//}

public class Song {

    // attributes
    protected String title;
    protected String artist;
    protected String genre;

    // constructor
    public Song() {
        this.title = "";
        this.artist = "";
        this.genre = "";
    }

    public String toString() {
        return this.title + " " + this.artist + " " + this.genre;
    }

    // getters
    public String getTitle() {
        return this.title;
    }

    public String getArtist() {
        return this.artist;
    }

    public String getGenre() {
        return this.genre;
    }

    // setters
    public void setTitle(String title) {
        this.title = title;
    }

    public void setArtist(String artist) {
        this.artist = artist;
    }

    public void setGenre(String genre) {
        this.genre = genre;
    }

}